@extends('layouts.fontend')
@section('main_content')
<div class="container mt-5">
    <div class="mt-5">
        {!! $slider->content !!}
    </div>

</div>
@endsection

