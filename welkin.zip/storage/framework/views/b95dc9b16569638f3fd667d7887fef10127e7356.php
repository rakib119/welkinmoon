
<?php $__env->startSection('main_content'); ?>

<section>
    <div class="w-100 pt-90 pb-100 position-relative">
        <div class="container">
            <div class="contact-wrap position-relative w-100">
                <div class="row mrg30">
                    <div class="col-md-5 col-sm-12 col-lg-4">
                        <div class="get-in-touch-wrap bg-color11 brd-rd20 mt-40 position-relative overflow-hidden w-100">
                            <h2 class="mb-0">Get in Touch</h2>
                            <p class="mb-0">SEOES is a USA search engine marketing agency, that deliver digital</p>
                            <div class="contact-info-box mt-40 d-flex flex-wrap w-100">
                                <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>
                                <div class="contact-info-inner">
                                    <h5 class="mb-0">Visit Us:</h5>
                                    <p class="mb-0">27 Division St, New York, NY 10002, USA</p>
                                </div>
                            </div>
                            <div class="contact-info-box mt-20 d-flex flex-wrap w-100">
                                <i class="flaticon-message-closed-envelope"></i>
                                <div class="contact-info-inner">
                                    <h5 class="mb-0">Mail Us:</h5>
                                    <a href="mailto:info@example.com" title="">info@example.com</a>
                                </div>
                            </div>
                            <div class="contact-info-box mt-20 d-flex flex-wrap w-100">
                                <i class="icon-037-smartphone"></i>
                                <div class="contact-info-inner">
                                    <h5 class="mb-0">Phone Us:</h5>
                                    <a href="tel:(305) 222-3333" title="">+(305) 222-3333</a>
                                </div>
                            </div>
                            <div class="social-links2 d-flex flex-wrap align-items-center w-100">
                                <a href="https://www.facebook.com/" title="Facebook" target="_blank">
                                    <svg class="svg_shape" xmlns="http://www.w3.org/2000/svg"><g><path d="M54.8,1.3l35.5,20.3c3,1.7,4.8,4.8,4.8,8.2v40.6c0,3.4-1.8,6.5-4.8,8.2L54.8,98.7c-3,1.7-6.6,1.7-9.5,0 L9.8,78.5c-3-1.7-4.8-4.8-4.8-8.2V29.7c0-3.4,1.8-6.5,4.8-8.2L45.2,1.3C48.2-0.4,51.8-0.4,54.8,1.3z"></path></g></svg>
                                    <i class="flaticon-facebook"></i>
                                </a>
                                <a href="https://twitter.com/" title="Twitter" target="_blank">
                                    <svg class="svg_shape" xmlns="http://www.w3.org/2000/svg"><g><path d="M54.8,1.3l35.5,20.3c3,1.7,4.8,4.8,4.8,8.2v40.6c0,3.4-1.8,6.5-4.8,8.2L54.8,98.7c-3,1.7-6.6,1.7-9.5,0 L9.8,78.5c-3-1.7-4.8-4.8-4.8-8.2V29.7c0-3.4,1.8-6.5,4.8-8.2L45.2,1.3C48.2-0.4,51.8-0.4,54.8,1.3z"></path></g></svg>
                                    <i class="flaticon-twitter"></i>
                                </a>
                                <a href="https://youtube.com/" title="Youtube" target="_blank">
                                    <svg class="svg_shape" xmlns="http://www.w3.org/2000/svg"><g><path d="M54.8,1.3l35.5,20.3c3,1.7,4.8,4.8,4.8,8.2v40.6c0,3.4-1.8,6.5-4.8,8.2L54.8,98.7c-3,1.7-6.6,1.7-9.5,0 L9.8,78.5c-3-1.7-4.8-4.8-4.8-8.2V29.7c0-3.4,1.8-6.5,4.8-8.2L45.2,1.3C48.2-0.4,51.8-0.4,54.8,1.3z"></path></g></svg>
                                    <i class="flaticon-youtube"></i>
                                </a>
                                <a href="https://linkedin.com/" title="Linkedin" target="_blank">
                                    <svg class="svg_shape" xmlns="http://www.w3.org/2000/svg"><g><path d="M54.8,1.3l35.5,20.3c3,1.7,4.8,4.8,4.8,8.2v40.6c0,3.4-1.8,6.5-4.8,8.2L54.8,98.7c-3,1.7-6.6,1.7-9.5,0 L9.8,78.5c-3-1.7-4.8-4.8-4.8-8.2V29.7c0-3.4,1.8-6.5,4.8-8.2L45.2,1.3C48.2-0.4,51.8-0.4,54.8,1.3z"></path></g></svg>
                                    <i class="flaticon-linkedin"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-12 col-lg-8">
                        <div class="contact-form-wrap mt-40 w-100">
                            <div class="sec-title w-100 position-relative">
                                <h2 class="mb-0">Send a Message</h2>
                                <i class="btm-ln bg-color3"></i>
                            </div>
                            <form action="<?php echo e(route('contact.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group w-100">
                                    <div class="response w-100"></div>
                                </div>
                                <div class="row mrg10">
                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                        <div class="field-box w-100">
                                            <input class="name" type="text" value="<?php echo e(old('name')); ?>" name="name" placeholder="Full Name*" required autofocus>
                                        </div>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <h6 class="text-danger"> <?php echo e($message); ?></h6>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                        <div class="field-box w-100">
                                            <input class="email" type="email" value="<?php echo e(old('email')); ?>" name="email" placeholder="Email *" required>
                                        </div>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <h6 class="text-danger">  <?php echo e($message); ?></h6>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                        <div class="field-box w-100">
                                            <input class="text" type="text" value="<?php echo e(old('subject')); ?>" name="subject" placeholder="Subject *" required>
                                        </div>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <h6 class="text-danger">  <?php echo e($message); ?></h6>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                        <div class="field-box w-100">
                                            <input class="photos" type="file" name="screenshots[]" placeholder="screenshot" accept=".jpg,.png" multiple>
                                        </div>
                                        <?php $__errorArgs = ['screenshots.1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <h6 class="text-danger">  <?php echo e($message); ?></h6>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-12 col-sm-12 col-lg-12">
                                        <div class="field-box w-100">
                                            <textarea class="contact_message" name="message" placeholder="Message" required> <?php echo e(old('message')); ?></textarea>
                                        </div>

                                        <div class="field-btn w-100">
                                            <button class="thm-btn d-inline-block rounded-pill" id="submit" type="submit">Send A Message</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div><!-- Contact Wrap -->
            <div class="contact-map w-100 overflow-hidden mt-50 brd-rd20">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3169.1859404323836!2d-122.05297108441484!3d37.40907974088707!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x808fb78af144de37%3A0xdd4791b7bab4679f!2sMoffett%20Federal%20Airfield!5e0!3m2!1sen!2s!4v1618730224931!5m2!1sen!2s"></iframe>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/welkinmoon/public_html/resources/views/fontend/contact.blade.php ENDPATH**/ ?>