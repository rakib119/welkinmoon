
<?php $__env->startSection('main_content'); ?>
<div class="container mt-5">
    <div class="mt-5">
        <?php echo $slider->content; ?>

    </div>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.fontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/welkinmoon/public_html/resources/views/fontend/slider.blade.php ENDPATH**/ ?>