

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-content">
        <!-- start page title -->
        <div class="page-title-box">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="page-title">
                            <h4>Add Information</h4>
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                                <li class="breadcrumb-item  "><a href="javascript:void(0)">Information</a>
                                <li class="breadcrumb-item active">Add Information</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end page title -->
        <div class="container-fluid">
            <div class="page-content-wrapper">
                <div class="row">
                    <div class="col-12">
                        <?php if(!$has_p_info && !$has_f_info && !$has_m_info ): ?>
                            <?php echo $__env->make('dashboard.information.yourinfo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($has_p_info && !$has_f_info && !$has_m_info): ?>
                            <?php echo $__env->make('dashboard.information.father_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($has_p_info && $has_f_info && !$has_m_info): ?>
                            <?php echo $__env->make('dashboard.information.mother_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!--<?php else: ?>-->
                        <!--    <?php echo $__env->make('dashboard.information.all_information', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/welkinmoon/public_html/resources/views/dashboard/information/index.blade.php ENDPATH**/ ?>