
<?php $__env->startSection('main_content'); ?>
<section style="margin-top: 100px">
    <div class="w-100 pt-130 pb-70 position-relative">
        <div class="fixed-bg back-size-cont bg-norepeate"
            style="background-image: url(assets/images/bg-shp-10.png);"></div>
            <div class="particles-wrap position-absolute w-100">
                <div id="particle-3" class="particles-js w-100" data-color="#fff" data-size="2" data-linked="1"
                    data-count="70" data-speed="5" data-hide="767" data-shape="circle" data-mode="out">
                    <canvas></canvas>
                </div>
            </div>
        <div class="container">
            <div class="sec-title text-white text-center w-100 position-relative">
                <h2 class="mb-0"> <?php echo e(__('Login')); ?></h2>
                <i class="btm-ln bg-white"></i>
            </div><!-- Sec Title -->
            <div class="cnt-wrap text-center position-relative w-100">

                <form class="w-100 d-inline-block" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group w-100">
                        <div class="response w-100"></div>
                    </div>
                    <div class="row mrg20">
                        
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="field-box w-100">
                                <input class="email <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" name="email" placeholder="Email Address"
                                name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback text-left" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="field-box w-100">
                                <input class="password  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password"
                                required autocomplete="current-password" placeholder="Password" required>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback text-left" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mt-3 d-flex justify-content-between">
                                <div>
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                        <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                     <label class="form-check-label text-white" for="remember">
                                         <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>
                                <div>
                                    <?php if(Route::has('password.request')): ?>
                                    <a class="btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="field-btn text-center w-100">
                                <button class="thm-btn d-inline-block rounded-pill" type="submit">submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div><!-- Contact Form Wrap -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/welkinmoon/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>